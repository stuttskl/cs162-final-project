/*********************************************************************
** Program name: Final Project
** Author: Katie Stutts
** Date:June 2nd, 2019
** Description:
*********************************************************************/
#include <iostream>
#include <string>
using std::cout;
using std::cin;
using std::endl;
using std::string;
#include "Knife.hpp"

/******************************************************
*
******************************************************/
Knife::Knife()
{
    name = "Knife";
    description = "Kind of dull, but still useful for cutting, stabbing, anything a knife is really good for.";
}

/******************************************************
*
******************************************************/
Knife::~Knife() {}