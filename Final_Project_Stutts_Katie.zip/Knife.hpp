/*********************************************************************
** Program name: Final Project
** Author: Katie Stutts
** Date:June 2nd, 2019
** Description:
*********************************************************************/
#ifndef FINAL_PROJECT_KNIFE_HPP
#define FINAL_PROJECT_KNIFE_HPP


#include "Item.hpp"

class Knife : public Item {
public:
    Knife();
    ~Knife();
};


#endif //FINAL_PROJECT_KNIFE_HPP
