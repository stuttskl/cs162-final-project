/*********************************************************************
** Program name: Final Project
** Author: Katie Stutts
** Date:June 2nd, 2019
** Description:
*********************************************************************/

#include "Item.hpp"
#ifndef FINAL_PROJECT_WOOD_HPP
#define FINAL_PROJECT_WOOD_HPP


class Wood : public Item {
public:
    Wood();
    ~Wood();
};


#endif //FINAL_PROJECT_WOOD_HPP
